<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\UserStoreCrudRequest;
use App\Http\Requests\UserUpdateCrudRequest;
use App\Models\User;
use App\Repositories\ContactRepository;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;

/**
 * Class UserCrudController
 * @package App\Http\Controllers\Admin
 * @property-read \Backpack\CRUD\app\Library\CrudPanel\CrudPanel $crud
 */
class UserCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation {
        store as traitStore;
    }
    use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation {
        update as traitUpdate;
    }
    use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\BulkDeleteOperation;
    protected $contectRepository;

    /**
     * Configure the CrudPanel object. Apply settings to all operations.
     * 
     * @return void
     */
    public function setup()
    {
        CRUD::setModel(\App\Models\User::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/user');
        CRUD::setEntityNameStrings('user', 'users');
        // $this->crud->setListView('backpack.users.list');

        $this->contectRepository = resolve(ContactRepository::class);
    }

    /**
     * Define what happens when the List operation is loaded.
     * 
     * @see  https://backpackforlaravel.com/docs/crud-operation-list-entries
     * @return void
     */
    protected function setupListOperation()
    {
        $this->crud->addColumns([
            [
                'name' => 'id',
                'label' => 'ID',
                'type' => 'text',
            ],
            [
                'name'  => 'name',
                'label' => trans('Name'),
                'type'  => 'text',
            ],
            [
                'name'  => 'email',
                'label' => trans('Email'),
                'type'  => 'email',
            ],
            [
                'name'  => 'phone',
                'label' => trans('Phone Number'),
                'type'  => 'text',
            ],
        ]);
        /**
         * Columns can be defined using the fluent syntax or array syntax:
         * - CRUD::column('price')->type('number');
         * - CRUD::addColumn(['name' => 'price', 'type' => 'number']); 
         */
    }

    /**
     * Define what happens when the Create operation is loaded.
     * 
     * @see https://backpackforlaravel.com/docs/crud-operation-create
     * @return void
     */
    protected function setupCreateOperation()
    {
        CRUD::setValidation(UserStoreCrudRequest::class);

        $this->addUserFields();
        /**
         * Fields can be defined using the fluent syntax or array syntax:
         * - CRUD::field('price')->type('number');
         * - CRUD::addField(['name' => 'price', 'type' => 'number'])); 
         */
    }

    /**
     * Define what happens when the Update operation is loaded.
     * 
     * @see https://backpackforlaravel.com/docs/crud-operation-update
     * @return void
     */
    protected function setupUpdateOperation()
    {
        $this->crud->setValidation(UserUpdateCrudRequest::class);
        $this->addUserFields();
    }

    public function store()
    {
        $this->crud->setRequest($this->crud->validateRequest());
        $this->crud->setRequest($this->handlePasswordInput($this->crud->getRequest()));
        $this->crud->unsetValidation();
        $fullname = request()->Salutation. " ". request()->FirstName. " " . request()->LastName;
        $response = $this->traitStore();
        $this->contectRepository->createContact($this->crud->entry, request());
        User::find($this->crud->entry->id)->update([
            'name' => $fullname
        ]);

        return $response;
    }
    public function update()
    {
        $this->crud->setRequest($this->crud->validateRequest());
        $this->crud->setRequest($this->handlePasswordInput($this->crud->getRequest()));
        $this->crud->unsetValidation();
        $full_name = request()->Salutation . " " . request()->FirstName . " " . request()->LastName;
        $response = $this->traitUpdate();

        $this->contectRepository->updateContact($this->crud->entry, request());
        User::find($this->crud->entry->id)->update([
            'name' => $full_name,
        ]);
        return $response;
    }
    protected function setupShowOperation(){
        $this->crud->setShowView('Admin.Users.show');
    }
       /**
     * Handle password input fields.
     */
    protected function handlePasswordInput($request)
    {
        // Remove fields not present on the user.
        $request->request->remove('password_confirmation');
        $request->request->remove('roles_show');
        $request->request->remove('permissions_show');

        // Encrypt password if specified.
        if ($request->input('password')) {
            $request->request->set('password', Hash::make($request->input('password')));
        } else {
            $request->request->remove('password');
        }

        return $request;
    }

    protected function addUserFields(){
        $colMd6 = ['class' => 'form-group col-md-6'];
        $this->crud->addFields([
            [
                'name' => 'Salutation',
                'type' => 'select2_from_array',
                'allows_null' => true,
                'label' => 'Salutation',
                'options' => ['Mr' => 'Mr', 'Ms' => 'Ms.', 'Mrs' => 'Mrs.', 'Oknha' => 'Oknha', 'H.E' => 'H.E', 'Dr' => 'Dr.', 'Neak Oknha' => 'Neak Oknha', 'Dato' => 'Dato'],
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'FirstName',
                'label' => 'FirstName',
                'type'  => 'text',
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'LastName',
                'label' => 'LastName',
                'type'  => 'text',
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'phone',
                'label' => 'Phone number',
                'type' => 'flexi.phone',
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'email',
                'label' => 'Email',
                'type' => 'text',
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'is_phone_verified',
                'label' => 'Verified phone',
                'type' => 'datetime_picker',
                'datetime_picker_options' => [
                    'format' => 'DD/MM/YYYY HH:mm',
                ],
                'allows_null' => true,
                'default' => Carbon::now(),
                'wrapper' => $colMd6
            ],
            [
                'name'  => 'password',
                'label' => 'Password',
                'type'  => 'password'
            ],
            [
                'name'  => 'password_confirmation',
                'label' => 'Confirmed password',
                'type'  => 'password'
            ],
            [
                // Custom Field From Contact
                'label' => 'Profile',
                'name' => "ProfileUser",
                'type' => 'image',
                'crop' => true, // set to true to allow cropping, false to disable
                'aspect_ratio' => 1, // omit or set to 0 to allow any aspect ratio
                // 'disk'      => 's3_bucket', // in case you need to show images from a different disk
                // 'prefix'    => 'uploads/images/profile_pictures/' // in case your db value is only the file name (no path), you can use this to prepend your path to the image src (in HTML), before it's shown to the user;
            ],
        ]);
    }
}
